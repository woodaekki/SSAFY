import socket
from collections import deque
import math

HOST = '127.0.0.1'
PORT = 8747

char_to_int = {'U': 0, 'R': 1, 'D': 2, 'L': 3}
map_data = [[]]
allies = {}
enemies = {}
codes = []

sock = socket.socket()

def init(nickname) -> str:
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}' 
        return submit(init_command)
    except Exception as e:
        print('[ERROR] Failed to connect.')
        print(e)

def submit(string_to_send) -> str:
    try:
        sock.send((string_to_send + ' ').encode('utf-8'))
        return receive()
    except Exception as e:
        print('[ERROR] Failed to send data.')
    return None

def receive() -> str:
    try:
        game_data = (sock.recv(1024)).decode()
        if int(game_data[0]) > 0:
            return game_data
        close()
    except Exception as e:
        print('[ERROR] Failed to receive data.')

def close():
    try:
        if sock is not None: sock.close()
        print('[STATUS] Connection closed')
    except Exception as e:
        print('[ERROR] Close failed.')

def parse_data(game_data):
    game_data_rows = game_data.split('\n')
    row_index = 0
    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0])
    map_width = int(header[1])
    num_of_allies = int(header[2])
    num_of_enemies = int(header[3])
    num_of_codes = int(header[4])
    row_index += 1

    map_data.clear()
    map_data.extend([[ '' for _ in range(map_width)] for _ in range(map_height)])
    for i in range(0, map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(0, map_width):
            map_data[i][j] = col[j]
    row_index += map_height

    allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0)
        allies[ally_name] = ally
    row_index += num_of_allies

    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0)
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])

NICKNAME = '광주1_김선우'
game_data = init(NICKNAME)

while game_data is not None:
    parse_data(game_data)

    lines = game_data.strip().split('\n')
    height, width, num_friends, num_enemies, num_codes = map(int, lines[0].split())
    raw_map = lines[1:1+height]
    unit_info = [line for line in lines[1+height:] if not (line.isalpha() and line.isupper() and len(line) >= 5)]

    unit_hp = {}
    for info in unit_info:
        parts = info.split()
        i = 0
        while i + 1 < len(parts):
            name = parts[i]
            hp = parts[i+1]
            if not hp.isdigit():
                break
            unit_hp[name] = int(hp)
            if name == 'A':
                direction = parts[i+2]
                normal_bullet = int(parts[i+3])
                mega_bullet = int(parts[i+4])
                i += 5
            else:
                i += 2

    def get_fire_command(direction, target_hp):
        global mega_bullet, normal_bullet
        if target_hp > 30:
            if mega_bullet > 0:
                mega_bullet -= 1
                return f"{direction} F M"
            elif normal_bullet > 0:
                normal_bullet -= 1
                return f"{direction} F"
        else:
            if normal_bullet > 0:
                normal_bullet -= 1
                return f"{direction} F"
            elif mega_bullet > 0:
                mega_bullet -= 1
                return f"{direction} F M"
        return 'S'

    map_data = []
    e_positions = {}
    ax = ay = tx = ty = -1
    for y in range(height):
        row = []
        for x, val in enumerate(raw_map[y].split()):
            if val.startswith('E'):
                e_positions[(x, y)] = unit_hp[val]
                row.append('E')
            else:
                row.append(val)
            if val == 'A':
                ax, ay = x, y
            elif val == 'X':
                tx, ty = x, y
        map_data.append(row)

    dir_map = {'U': (0, -1), 'D': (0, 1), 'L': (-1, 0), 'R': (1, 0)}
    rev_dir = {(0, -1): 'U', (0, 1): 'D', (-1, 0): 'L', (1, 0): 'R'}

    def find_visible_target(ax, ay, targets):
        for d, (dx, dy) in dir_map.items():
            for i in range(1, 4):
                nx, ny = ax + dx * i, ay + dy * i
                if not (0 <= nx < width and 0 <= ny < height): break
                tile = map_data[ny][nx]
                if (nx, ny) in targets:
                    hp = unit_hp['X'] if tile == 'X' else e_positions.get((nx, ny), 30)
                    return get_fire_command(d, hp)
                elif tile not in ['G', 'A']:
                    break
        return None

    def bfs_path(start, targets, max_bullet):
        q = deque()
        visited = [[False]*width for _ in range(height)]
        used = [[0]*width for _ in range(height)]
        parent = [[None]*width for _ in range(height)]
        sx, sy = start
        q.append((sx, sy))
        visited[sy][sx] = True

        while q:
            x, y = q.popleft()
            if (x, y) in targets:
                path = []
                while (x, y) != (sx, sy):
                    path.append((x, y))
                    x, y = parent[y][x]
                path.reverse()
                return path

            for dx, dy in dir_map.values():
                nx, ny = x + dx, y + dy
                if not (0 <= nx < width and 0 <= ny < height) or visited[ny][nx]:
                    continue
                tile = map_data[ny][nx]
                if tile == 'B': continue
                cost = 0
                if tile == 'G':
                    cost = 0
                elif tile == 'E' and (nx, ny) in e_positions:
                    cost = math.ceil(e_positions[(nx,ny)] / 30)
                elif tile == 'T':
                    cost = 1
                else:
                    continue

                if used[y][x] + cost <= max_bullet:
                    visited[ny][nx] = True
                    used[ny][nx] = used[y][x] + cost
                    parent[ny][nx] = (x, y)
                    q.append((nx, ny))
        return None

    # 수비 로직
    output = None
    usable_bullet = normal_bullet + mega_bullet

    # H 위치 탐색
    hx = hy = -1
    for y in range(height):
        for x in range(width):
            if map_data[y][x] == 'H':
                hx, hy = x, y
                break
        if hx != -1: break

    # H 기준 5x5 정사각형을 B로 치환
    for dy in range(-2, 3):
        for dx in range(-2, 3):
            nx, ny = hx + dx, hy + dy
            if 0 <= nx < width and 0 <= ny < height:
                if map_data[ny][nx] == 'G':
                    map_data[ny][nx] = 'B'

    # G 중 배회 가능 지역 필터링
    guard_zone = set()
    for dy in range(-3, 4):
        for dx in range(-3, 4):
            nx, ny = hx + dx, hy + dy
            if not (0 <= nx < width and 0 <= ny < height):
                continue
            if map_data[ny][nx] != 'G':
                continue
            manhattan_dist = abs(dx) + abs(dy)
            if (dx == 0 and 0 < abs(dy) <= 2) or (dy == 0 and 0 < abs(dx) <= 2):
                continue
            guard_zone.add((nx, ny))

    # 적 보이면 발포
    output = find_visible_target(ax, ay, set(e_positions.keys()))
    if output:
        pass
    else:
        # E 유닛이 없을 수도 있으니, 없으면 S
        if e_positions:
            # guard_zone을 E들 중 가장 가까운 거리 기준으로 정렬
            def closest_enemy_dist(pos):
                x, y = pos
                return min(abs(x - ex) + abs(y - ey) for (ex, ey) in e_positions)

            sorted_guard_zone = sorted(guard_zone, key=closest_enemy_dist)

            # 가까운 곳부터 BFS 시도
            path = None
            for target in sorted_guard_zone:
                path = bfs_path((ax, ay), {target}, usable_bullet)
                if path:
                    break

            if path:
                nx, ny = path[0]
                dx, dy = nx - ax, ny - ay
                direction = rev_dir[(dx, dy)]
                output = f"{direction} A"
            else:
                output = 'S'
        else:
            output = 'S'


    game_data = submit(output)
