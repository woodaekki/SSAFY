import socket

HOST = '127.0.0.1'
PORT = 8747

# 입력 데이터 분류
char_to_int = {'U': 0, 'R': 1, 'D': 2, 'L': 3}
map_data = [[]]  # 맵 정보. 예) map_data[0][1] - [0, 1]의 지형/지물
allies = {}  # 아군 정보. 예) allies['A'] - 플레이어 본인의 정보
enemies = {}  # 적군 정보. 예) enemies['X'] - 적 포탑의 정보
codes = []  # 주어진 암호문. 예) codes[0] - 첫 번째 암호문

sock = socket.socket()

def init(nickname) -> str:
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}' 

        return submit(init_command)

    except Exception as e:
        print('[ERROR] Failed to connect. Please check if Battle SSAFY is waiting for connection.')
        print(e)

def submit(string_to_send) -> str:
    try:
        sock.send((string_to_send + ' ').encode('utf-8'))

        return receive()
        
    except Exception as e:
        print('[ERROR] Failed to connect. Please check if Battle SSAFY is waiting for connection.')

    return None

def receive() -> str:
    try:
        game_data = (sock.recv(1024)).decode()

        if int(game_data[0]) > 0:
            return game_data
            
        close()
    except Exception as e:
        print('[ERROR] Failed to connect. Please check if Battle SSAFY is waiting for connection.')

def close():
    try:
        if sock is not None: sock.close()
        print('[STATUS] Connection closed')
    
    except Exception as e:
        print('[ERROR] Network connection has been corrupted.')

# 입력 데이터를 파싱하여 변수에 저장
def parse_data(game_data):
    # 입력 데이터를 행으로 나누기
    game_data_rows = game_data.split('\n')
    row_index = 0

    # 첫 번째 행 데이터 읽기
    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0])  # 맵의 세로 크기
    map_width = int(header[1])  # 맵의 가로 크기
    num_of_allies = int(header[2])  # 아군의 수
    num_of_enemies = int(header[3])  # 적군의 수
    num_of_codes = int(header[4])  # 암호문의 수
    row_index += 1

    # 기존의 맵 정보를 초기화하고 다시 읽어오기
    map_data.clear()
    map_data.extend([[ '' for c in range(map_width)] for r in range(map_height)])
    for i in range(0, map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(0, map_width):
            map_data[i][j] = col[j]
    row_index += map_height

    # 기존의 아군 정보를 초기화하고 다시 읽어오기
    allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0)
        allies[ally_name] = ally
    row_index += num_of_allies

    # 기존의 적군 정보를 초기화하고 다시 읽어오기
    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0)
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    # 기존의 암호문 정보를 초기화하고 다시 읽어오기
    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])





import heapq
def bfs(y, x):
    missile1, missile2 = missiles
    missile1 = int(missile1)
    missile2 = int(missile2)
    pq = [(0, y, x, missile1, missile2, [], 0)]
    visited = [[0] * N for _ in range(N)]

    while pq:
        k, i, j, m1, m2, p, t = heapq.heappop(pq)
        if visited[i][j] != 0:
            continue
        visited[i][j] = 1
        if map_data[i][j] == "X":
            action = [move_directions[p[0]], m1, m2, t]
            return action

        for di, dj in ((-1, 0), (0, 1), (1, 0), (0, -1)):
            ni, nj = i + di, j + dj
            if 0 <= ni < N and 0 <= nj < N and visited[ni][nj] == 0:
                if map_data[ni][nj] == "G" or map_data[ni][nj] == "X":
                    heapq.heappush(pq, (k + 1, ni, nj, m1, m2, p + [(di, dj)], t))
                elif map_data[ni][nj] in ("T", "E1", "E2", "E3") and m1 + m2 >= 2:
                    if m1 > 0:
                        heapq.heappush(pq, ((k + 2, ni, nj, m1 - 1, m2, p + [(di, dj)], 1)))
                    else:
                        heapq.heappush(pq, ((k + 2, ni, nj, m1, m2 - 1, p + [(di, dj)], 1)))
    return ['NO', m1, m2, t]


from collections import deque
def password_bfs(y, x):
    dq = deque([(y, x, [])])
    visited = [[0] * N for _ in range(N)]

    while dq:
        i, j, p = dq.popleft()
        if visited[i][j] != 0:
            continue
        visited[i][j] = 1
        if map_data[i][j] == "F":
            action = move_directions[p[0]]
            return action
        for di, dj in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            ni, nj = i + di, j + dj
            if 0 <= ni < N and 0 <= nj < N and visited[ni][nj] == 0 and map_data[ni][nj] in ("G", "F"):
                dq.append((ni, nj, p + [(di, dj)]))
    return 0

    

def fire(i, j, m1, m2):
    for di, dj in ((-1, 0), (0, 1), (1, 0), (0, -1)):
        for k in range(1, 4):
            ni, nj = i + di * k, j + dj * k
            if 0 <= ni < N and 0 <= nj < N and m1 + m2 > 0:
                if map_data[ni][nj] == "X":
                    if m1 > 0:
                        action = fire_directions[(di, dj)]
                    elif m2 > 0:
                        action = fire_directions[(di, dj)] + " M"
                    return action
                elif map_data[ni][nj] == "G":
                    continue
                else:
                    break
    return -1

def fireToEmemy(i, j, m1, m2):
    for di, dj in ((-1, 0), (0, 1), (1, 0), (0, -1)):
        for k in range(1, 4):
            ni, nj = i + di * k, j + dj * k
            if 0 <= ni < N and 0 <= nj < N and m1 + m2 > 0:
                if map_data[ni][nj] in ("E1", "E2", "E3"):
                    if m2 > 0:
                        action = fire_directions[(di, dj)] + " M"
                    elif m1 > 0:
                        action = fire_directions[(di, dj)]
                    return action
                elif map_data[ni][nj] == "G":
                    continue
                else:
                    break
    return 0


def find(t):
    for i in range(N):
        if map_data[i].count(t):
            return i, map_data[i].index(t)
    return 0

def decoder_box_near(i, j):
    for di, dj in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        ni, nj = i + di, j + dj
        if 0 <= ni < N and 0 <= nj < N and map_data[ni][nj] == "F":
            return "G "
    return 0


def decode(data):
    global decode_count
    print(data)
    result = ''
    for d in data:
        nds = ord(d) + decode_count
        if nds > 90:
            nds -= 26
        result += chr(nds)
    decode_count += 1
    if decode_count > 25:
        decode_count = 1
    return result


move_directions = {
    (-1, 0): "U A",
    (1, 0): "D A",
    (0, -1): "L A",
    (0, 1): "R A",
}

fire_directions = {
    (-1, 0): "U F",
    (1, 0): "D F",
    (0, -1): "L F",
    (0, 1): "R F",
}

move_delta = {
    "U A": (-1, 0),
    "D A": (1, 0),
    "L A": (0, -1),
    "R A": (0, 1),
}

tree_fire = {
    "U A": "U F",
    "D A": "D F",
    "L A": "L F",
    "R A": "R F",
}

decode_count = 1

NICKNAME = '광주1_김민우'
game_data = init(NICKNAME)

# while 반복문: 배틀싸피 메인 프로그램과 클라이언트(이 코드)가 데이터를 계속해서 주고받는 부분
while game_data is not None:
    # 자기 차례가 되어 받은 게임정보를 파싱
    print(f'----입력데이터----\n{game_data}\n----------------')
    parse_data(game_data)

    # 파싱한 데이터를 화면에 출력하여 확인
    print(f'\n[맵 정보] ({len(map_data)} x {len(map_data[0])})')
    for i in range(len(map_data)):
        for j in range(len(map_data[i])):
            print(f'{map_data[i][j]} ', end='')
        print()

    print(f'\n[아군 정보] (아군 수: {len(allies)})')
    for k, v in allies.items():
        if k == 'A':
            print(f'A (내 탱크) - 체력: {v[0]}, 방향: {v[1]}, 보유한 일반 포탄: {v[2]}개, 보유한 메가 포탄: {v[3]}개')
        elif k == 'H':
            print(f'H (아군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (아군 탱크) - 체력: {v[0]}')

    print(f'\n[적군 정보] (적군 수: {len(enemies)})')
    for k, v in enemies.items():
        if k == 'X':
            print(f'X (적군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (적군 탱크) - 체력: {v[0]}')

    print(f'\n[암호문 정보] (암호문 수: {len(codes)})')
    for i in range(len(codes)):
        print(codes[i])



    # 탱크의 동작을 결정하기 위한 알고리즘을 구현하고 원하는 커맨드를 output 변수에 담기

    N = len(map_data)
    for k, v in allies.items():
        if k == 'A':
            missiles = [v[2], v[3]]

    missile1, missile2 = missiles
    missile1 = int(missile1)
    missile2 = int(missile2)

    my_position = [-1, -1]
    for i in range(len(map_data)):
        for j in range(len(map_data[0])):
            if map_data[i][j] == 'A':
                my_position[0] = i
                my_position[1] = j
                break
        if my_position[0] > 0: break

    move_data = bfs(my_position[0], my_position[1])
    output = move_data[0]
    y, x = find("A")
    if move_data[3] == 1:
        ni, nj = y + move_delta[output][0], x + move_delta[output][1]
        if map_data[ni][nj] in ("T", "E1", "E2", "E3"):
            output = tree_fire[output]

    fire_possible = fire(y, x, move_data[1], move_data[2])
    if fire_possible != -1:
        output = fire_possible
    
    fire2enemy = fireToEmemy(my_position[0], my_position[1], missile1, missile2)
    if fire2enemy:
        output = fire2enemy


    # while 문의 끝에는 다음 코드가 필수로 존재하여야 함
    # output에 담긴 값은 submit 함수를 통해 배틀싸피 메인 프로그램에 전달
    game_data = submit(output)


# 반복문을 빠져나왔을 때 배틀싸피 메인 프로그램과의 연결을 완전히 해제하기 위해 close 함수 호출
close()