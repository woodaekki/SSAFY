import socket
import heapq

# 방향 딕셔너리: 네 방향 이동 벡터
d = {'U': (-1, 0), 'D': (1, 0), 'L': (0, -1), 'R': (0, 1)}

HOST = '127.0.0.1'
PORT = 8747

# 입력 데이터 분류
char_to_int = {'U': 0, 'R': 1, 'D': 2, 'L': 3}
map_data = [[]]  # 맵 정보 (2차원 리스트)
allies = {}  # 아군 정보
enemies = {}  # 적군 정보
codes = []  # 암호문 리스트

sock = socket.socket()


def init(nickname) -> str:
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}'
        return submit(init_command)
    except Exception as e:
        print('[ERROR] Failed to connect. Please check if Battle SSAFY is waiting for connection.')
        print(e)


def submit(string_to_send) -> str:
    try:
        sock.send((string_to_send + ' ').encode('utf-8'))
        return receive()
    except Exception as e:
        print('[ERROR] Failed to submit.')
    return None


def receive() -> str:
    try:
        game_data = (sock.recv(1024)).decode()
        if int(game_data[0]) > 0:
            return game_data
        close()
    except Exception as e:
        print('[ERROR] Failed to receive.')


def close():
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')
    except Exception as e:
        print('[ERROR] Failed to close the connection.')


def parse_data(game_data):
    game_data_rows = game_data.split('\n')
    row_index = 0
    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0])
    map_width = int(header[1])
    num_of_allies = int(header[2])
    num_of_enemies = int(header[3])
    num_of_codes = int(header[4])
    row_index += 1

    map_data.clear()
    map_data.extend([['' for _ in range(map_width)] for _ in range(map_height)])
    for i in range(map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(map_width):
            map_data[i][j] = col[j]
    row_index += map_height

    allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0)
        allies[ally_name] = ally
    row_index += num_of_allies

    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0)
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])


def caesar_decrypt(cipher_text, shift):
    result = ""
    for char in cipher_text:
        if 'A' <= char <= 'Z':
            result += chr((ord(char) - ord('A') - shift) % 26 + ord('A'))
        else:
            result += char
    return result


def brute_force_caesar(cipher_text):
    results = {}
    for shift in range(26):
        results[shift] = caesar_decrypt(cipher_text, shift)
    return results


def re_path(state, parent):
    path = []
    while parent[state] is not None:
        state, action = parent[state]
        path.append(action)
    path.reverse()
    return path


def fire(x, y, target_tank, h, w):
    for key, (dx, dy) in d.items():
        for i in range(1, 4):
            nx, ny = x + dx * i, y + dy * i
            if not (0 <= nx < h and 0 <= ny < w):
                break
            # 비교: 적 탱크는 'X'로 표현됨
            if map_data[nx][ny] == 'X' or map_data[nx][ny].startswith('E'):
                return f'{key} F'
            if map_data[nx][ny] != 'G':
                break
    return None

def get_action(sR, sC, eR, eC, tR, tC):
    rows = len(map_data)
    cols = len(map_data[0])

    bomb_init = int(allies["A"][2])
    bigbomb_init = int(allies["A"][3])
    start_state = (sR, sC, bomb_init, bigbomb_init)
    h_around = []
    for i in range(1,4):
        for j in range(1,4):
            h_around.append((tR+i,tC+j))
            h_around.append((tR-i,tC+j))
            h_around.append((tR + i,tC - j))
            h_around.append((tR - i,tC - j))
    dist = {start_state: 0}
    visited = set()
    parent = {start_state: None}

    # target 집합: 여기서는 공급시설 'F' 뿐만 아니라 (추가) 적 탱크('X') 블록에 대해
    # 목표가 되는 좌표를 구성합니다.
    # 만약 공급시설 'F' 타일이 있으면 그곳으로 이동하고, 없으면 'X' 타일에 대해 처리합니다.
    target = set()
    for i in range(rows):
        for j in range(cols):
            if map_data[i][j] == 'F':
                target.add((i, j))
    # 만약 target 집합이 빈 경우, 기본적으로 적 탱크 주변 'G' 셀로 구성할 수도 있음.
    if not target:
        for dx, dy in d.values():
            for i in range(1, 4):
                nx, ny = eR + dx * i, eC + dy * i
                if 0 <= nx < rows and 0 <= ny < cols and map_data[nx][ny] == 'G':
                    target.add((nx, ny))

    def heu(state):
        x, y, b, bb = state
        return min(abs(x - tx) + abs(y - ty) for (tx, ty) in target) if target else 0

    pq = []
    heapq.heappush(pq, (dist[start_state] + heu(start_state), dist[start_state], start_state))

    while pq:
        f_val, g_val, state = heapq.heappop(pq)
        if state in visited:
            continue
        visited.add(state)
        x, y, bombcnt, bigbombcnt = state
        current_cost = dist[state]
        if target:
            best_target = min(target, key=lambda t: abs(x - t[0]) + abs(y - t[1]))
        else:
            best_target = (eR, eC)  # target 집합이 비어 있으면 고정 포탑을 기본으로 사용

        if (x, y) in target:
            fire_command = fire(x, y, best_target, rows, cols)
            if fire_command is not None:
                path = re_path(state, parent)
                path.append(fire_command)
                return path

        fire_command = fire(x, y, best_target, rows, cols)
        if fire_command is not None:
            path = re_path(state, parent)
            path.append(fire_command)
            return path

        for key, (dx, dy) in d.items():
            nx = x + dx
            ny = y + dy
            if 0 <= nx < rows and 0 <= ny < cols:
                new_state = None
                new_cost = float('inf')
                tile = map_data[nx][ny]
                action = key + ' A'

                if tile == 'F':
                    if bigbombcnt >= 1:
                        continue
                    new_state = (nx, ny, bombcnt, bigbombcnt + 1)
                    new_cost = current_cost + 2
                elif tile == 'T':
                    if bombcnt <= 0 and bigbombcnt <= 0:
                        continue
                    if bombcnt > 0:
                        new_state = (nx, ny, bombcnt - 1, bigbombcnt)
                    else:
                        new_state = (nx, ny, bombcnt, bigbombcnt - 1)
                    new_cost = current_cost + 2
                    action = key + ' F'
                elif tile == 'X':
                    # 적 탱크 블록: 길을 막고 있는 경우, 포탄이 있으면 제거(쏘기) 후 진행
                    if bombcnt <= 0 and bigbombcnt <= 0:
                        continue
                    if bombcnt > 0:
                        new_state = (nx, ny, bombcnt - 1, bigbombcnt)
                    else:
                        new_state = (nx, ny, bombcnt, bigbombcnt - 1)
                    new_cost = current_cost + 2
                    action = key + ' F'
                elif tile in ['R', 'W']:
                    continue
                elif (nx, ny) in target:
                    if bombcnt <= 0 and bigbombcnt <= 0:
                        continue
                    if bombcnt > 0:
                        new_state = (nx, ny, bombcnt - 1, bigbombcnt)
                    else:
                        new_state = (nx, ny, bombcnt, bigbombcnt - 1)
                    new_cost = current_cost + 1
                    temp_fire = fire(nx, ny, (eR, eC), rows, cols)
                    if temp_fire is not None:
                        parent[new_state] = (state, action)
                        path = re_path(new_state, parent)
                        path.append(temp_fire)
                        return path
                elif len(tile) >= 2 and tile[0] == 'E':
                    if bombcnt <= 0 and bigbombcnt <= 0:
                        continue
                    new_state = (nx, ny, bombcnt, bigbombcnt - 1)
                    new_cost = current_cost + 2
                    action = key + ' F'
                else:
                    if tile != 'G':
                        continue
                    new_state = (nx, ny, bombcnt, bigbombcnt)
                    new_cost = current_cost + 1
                if (nx,ny) in h_around:
                    continue
                if new_state is None:
                    continue
                if new_state not in dist or new_cost < dist[new_state]:
                    dist[new_state] = new_cost
                    parent[new_state] = (state, action)
                    heapq.heappush(pq, (new_cost + heu(new_state), new_cost, new_state))
    return "No Action"


NICKNAME = '광주1_오승호'
game_data = init(NICKNAME)

while game_data is not None:
    print(f'----입력데이터----\n{game_data}\n----------------')
    parse_data(game_data)

    print(f'\n[맵 정보] ({len(map_data)} x {len(map_data[0])})')
    for i in range(len(map_data)):
        for j in range(len(map_data[i])):
            print(f'{map_data[i][j]} ', end='')
        print()

    print(f'\n[아군 정보] (아군 수: {len(allies)})')
    for k, v in allies.items():
        if k == 'A':
            print(f'A (내 탱크) - 체력: {v[0]}, 방향: {v[1]}, 보유한 일반 포탄: {v[2]}개, 보유한 메가 포탄: {v[3]}개')
        elif k == 'H':
            print(f'H (아군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (아군 탱크) - 체력: {v[0]}')

    print(f'\n[적군 정보] (적군 수: {len(enemies)})')
    for k, v in enemies.items():
        if k == 'X':
            print(f'X (적군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (적군 탱크) - 체력: {v[0]}')

    print(f'\n[암호문 정보] (암호문 수: {len(codes)})')
    for i in range(len(codes)):
        print(codes[i])

    for i in range(len(map_data)):
        for j in range(len(map_data[0])):
            if map_data[i][j] == 'A':
                start_row, start_col = i, j
            if map_data[i][j] == 'F':
                end_row, end_col = i, j
            if map_data[i][j] == 'H':
                top_row, top_col = i,j

    output_temp = get_action(start_row, start_col, end_row, end_col,top_row, top_col)
    if output_temp == "No Action":
        output = "S"
    else:
        # output_temp가 리스트라면 첫번째 명령을 선택 (또는 원하는 방식으로 처리)
        output = output_temp[0]
    game_data = submit(output)

close()